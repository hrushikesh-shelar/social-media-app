# FullStack Social Media App

Build a COMPLETE Fullstack Responsive MERN App with Auth, Likes, Dark Mode | React, MongoDB, MUI

Video: https://www.youtube.com/watch?v=K8YELRmUb5o

For all related questions and discussions about this project, check out the discord: https://discord.gg/2FfPeEk2mX
